package no.fintlabs.kafka.common.topic;

public interface TopicNamePatternParameters {
}
